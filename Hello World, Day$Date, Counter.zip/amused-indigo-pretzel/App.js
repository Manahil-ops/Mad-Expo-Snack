import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

export default function App() {
  const [counter, setCounter] = useState(0);

  const currentDate = new Date();
  const date = currentDate.toLocaleDateString();
  const day = currentDate.toLocaleDateString('en-US', { weekday: 'long' });

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Welcome to the Counter App</Text>
      <Text style={styles.dateText}>Today is {day}, {date}</Text>
      
      <Card style={styles.cardContainer}>
        <AssetExample />
      </Card>
      
      <View style={styles.counterContainer}>
        <Text style={styles.counterText}>Count: {counter}</Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={[styles.button, styles.increment]} onPress={() => setCounter(counter + 1)}>
            <Text style={styles.buttonText}>+</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.decrement]} onPress={() => setCounter(counter - 1)}>
            <Text style={styles.buttonText}>-</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.reset]} onPress={() => setCounter(0)}>
            <Text style={styles.buttonText}>Reset</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e3f2fd',
    padding: 16,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  dateText: {
    fontSize: 16,
    marginBottom: 20,
  },
  cardContainer: {
    width: '90%',
    padding: 10,
    marginBottom: 20,
  },
  counterContainer: {
    alignItems: 'center',
  },
  counterText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 10,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  increment: {
    backgroundColor: '#4caf50',
  },
  decrement: {
    backgroundColor: '#f44336',
  },
  reset: {
    backgroundColor: '#ff9800',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});