import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, TouchableOpacity, View, TextInput } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handlePress = (value) => {
    if (value === '=') {
      try {
        setResult(eval(input).toString());
      } catch {
        setResult('Error');
      }
    } else if (value === 'C') {
      setInput('');
      setResult('');
    } else {
      setInput((prev) => prev + value);
    }
  };

  const scientificOperations = (operation) => {
    try {
      let evalResult;
      if (operation === 'sin') evalResult = Math.sin(eval(input));
      if (operation === 'cos') evalResult = Math.cos(eval(input));
      if (operation === 'tan') evalResult = Math.tan(eval(input));
      if (operation === 'log') evalResult = Math.log10(eval(input));
      if (operation === 'ln') evalResult = Math.log(eval(input));
      if (operation === '√') evalResult = Math.sqrt(eval(input));
      if (operation === '^') evalResult = Math.pow(eval(input.split('^')[0]), eval(input.split('^')[1]));
      if (operation === '%') evalResult = eval(input) / 100;
      setResult(evalResult.toString());
    } catch {
      setResult('Error');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Advanced Scientific Calculator</Text>
      <TextInput style={styles.input} value={input} editable={false} />
      <Text style={styles.result}>{result}</Text>
      <View style={styles.buttonGrid}>
        {['7', '8', '9', '/', 'sin', 'cos', 'tan', '√', '4', '5', '6', '*', 'log', 'ln', '(', ')', '1', '2', '3', '-', '0', '.', 'C', '=', '+', '^', '%'].map((item) => (
          <TouchableOpacity key={item} style={styles.button} onPress={() => item.match(/\d|\.|\+|\-||\/|\(|\)|\^|%/) ? handlePress(item) : scientificOperations(item)}>
            <Text style={styles.buttonText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  heading: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    width: '85%',
    height: 60,
    fontSize: 28,
    textAlign: 'right',
    padding: 15,
    backgroundColor: 'white',
    marginBottom: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  result: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: '90%',
  },
  button: {
    width: '22%',
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 5,
    backgroundColor: '#1e90ff',
    borderRadius: 8,
    elevation: 3,
  },
  buttonText: {
    fontSize: 22,
    color: 'white',
    fontWeight: 'bold',
  },
});