import React, { useEffect, useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';

export default function App() {
  const [orientation, setOrientation] = useState('PORTRAIT');
  const [isLocked, setIsLocked] = useState(false);

  // Detect the current screen orientation
  const detectOrientation = async () => {
    const orientation = await ScreenOrientation.getOrientationAsync();
    if (orientation === ScreenOrientation.Orientation.PORTRAIT_UP || orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN) {
      setOrientation('PORTRAIT');
    } else {
      setOrientation('LANDSCAPE');
    }
  };

  // Toggle screen orientation
  const toggleOrientation = async () => {
    if (orientation === 'PORTRAIT') {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    }
    detectOrientation(); // Update the orientation state
  };

  // Lock or unlock the screen orientation
  const toggleLock = async () => {
    if (isLocked) {
      setIsLocked(false);
      await ScreenOrientation.unlockAsync();
    } else {
      setIsLocked(true);
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LOCKED);
    }
  };

  // Detect orientation on load and when it changes
  useEffect(() => {
    detectOrientation();

    const subscription = ScreenOrientation.addOrientationChangeListener(() => {
      if (!isLocked) {
        detectOrientation();
      }
    });

    return () => {
      ScreenOrientation.removeOrientationChangeListener(subscription);
    };
  }, [isLocked]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        {orientation === 'PORTRAIT' ? 'Vertical Page' : 'Horizontal Page'}
      </Text>
      <View style={orientation === 'PORTRAIT' ? styles.cardPortrait : styles.cardLandscape}>
        <Text style={styles.cardText}>Hello, SAIM!</Text>
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: isLocked ? 'red' : '#5F8575' }]}
          onPress={toggleLock}
        >
          <Text style={styles.buttonText}>{isLocked ? 'Unlock Orientation' : 'Lock Orientation'}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#5F8575' }]}
          onPress={toggleOrientation}
        >
          <Text style={styles.buttonText}>{orientation === 'PORTRAIT' ? 'Switch to Horizontal Page' : 'Switch to Vertical Page'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#50C878',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  cardPortrait: {
    width: 250,
    height: 250,
    backgroundColor: '#5F8575',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
    marginBottom: 20,
  },
  cardLandscape: {
    width: 350,
    height: 200,
    backgroundColor: '#BF77F6',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
    marginBottom: 20,
  },
  cardText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
  },
  button: {
    padding: 15,
    borderRadius: 10,
    margin: 5,
    width: '45%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
})