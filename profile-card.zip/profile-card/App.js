import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const ProfileCard = () => {
  return (
    <View style={styles.card}>
      <View style={styles.textContainer}>
        <Text style={styles.name}>Manahil Mustafa</Text>
        <Text style={styles.bio}>Software Engineer | UI/UX Designer</Text>
        <Text style={styles.info}>
          Passionate about designing intuitive user experiences, specializing in front-end development, Figma, and React Native.
        </Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Follow</Text>
        </TouchableOpacity>
      </View>
      <Image
        source={{ uri: 'https://randomuser.me/api/portraits/women/50.jpg' }} // New profile picture
        style={styles.image}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fdf6e3', // Light warm tone background
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
    margin: 20,
  },
  textContainer: {
    flex: 1,
    paddingRight: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000', // Black color for name
  },
  bio: {
    fontSize: 16,
    color: '#333', // Dark Gray for better readability
    marginVertical: 4,
    fontWeight: '600',
  },
  info: {
    fontSize: 14,
    color: '#444', // Slightly darker gray for additional info
    marginBottom: 8,
  },
  button: {
    backgroundColor: '#ff4081', // Pinkish tone for creative feel
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginTop: 8,
    shadowColor: '#d81b60',
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: '#ddd',
  },
});

export default ProfileCard;