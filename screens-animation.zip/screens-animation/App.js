import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Easing } from 'react-native';

const App = () => {
  const [currentScreen, setCurrentScreen] = useState(0);
  const slideAnim = useState(new Animated.Value(0))[0];

  const screens = [
    {
      title: 'Screen 1',
      description: 'This is the first screen. Swipe or tap to go to the next screen.',
      backgroundColor: '#FF6F61',
    },
    {
      title: 'Screen 2',
      description: 'This is the second screen. Swipe or tap to go to the next screen.',
      backgroundColor: '#6B5B95',
    },
    {
      title: 'Screen 3',
      description: 'This is the third screen. Swipe or tap to go back to the first screen.',
      backgroundColor: '#88B04B',
    },
  ];

  const handleNext = () => {
    Animated.timing(slideAnim, {
      toValue: -500, // Slide out to the left
      duration: 500,
      easing: Easing.linear,
      useNativeDriver: true,
    }).start(() => {
      slideAnim.setValue(500); // Reset to the right
      setCurrentScreen((prev) => (prev + 1) % screens.length);
      Animated.timing(slideAnim, {
        toValue: 0, // Slide in from the right
        duration: 500,
        easing: Easing.linear,
        useNativeDriver: true,
      }).start();
    });
  };

  const handlePrevious = () => {
    Animated.timing(slideAnim, {
      toValue: 500, // Slide out to the right
      duration: 500,
      easing: Easing.linear,
      useNativeDriver: true,
    }).start(() => {
      slideAnim.setValue(-500); // Reset to the left
      setCurrentScreen((prev) => (prev - 1 + screens.length) % screens.length);
      Animated.timing(slideAnim, {
        toValue: 0, // Slide in from the left
        duration: 500,
        easing: Easing.linear,
        useNativeDriver: true,
      }).start();
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: screens[currentScreen].backgroundColor }]}>
      <Animated.View
        style={[
          styles.screen,
          {
            transform: [{ translateX: slideAnim }],
          },
        ]}
      >
        <Text style={styles.title}>{screens[currentScreen].title}</Text>
        <Text style={styles.description}>{screens[currentScreen].description}</Text>
      </Animated.View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handlePrevious}>
          <Text style={styles.buttonText}>Previous</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleNext}>
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  screen: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
  },
  description: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 50,
  },
  button: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 30,
    marginHorizontal: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default App;